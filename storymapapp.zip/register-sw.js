// register-sw.js

if ('serviceWorker' in navigator && 'PushManager' in window) {
  window.addEventListener('load', async () => {
    try {
      const registration = await navigator.serviceWorker.register('/service-worker.js');
      console.log('Service Worker registered');

      // Minta izin push
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') return;

      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: 'https://story-api.dicoding.dev/v1',
      });

      console.log('Push subscription:', JSON.stringify(subscription));
      // Kirim subscription ke server kamu jika perlu
    } catch (error) {
      console.error('SW registration failed:', error);
    }
  });
}
