const CACHE_NAME = 'map-explorer-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/styles/main.css',
  '/images/logo.png',
  '/images/icons/icon-192x192.png',
  // Tambahkan file lainnya yang penting
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_ASSETS))
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then(
      (response) => response || fetch(event.request)
    )
  );
});
// service-worker.js

self.addEventListener('push', (event) => {
  const data = event.data?.json() || {
    title: 'Notifikasi Baru!',
    body: 'Ada informasi baru dari aplikasi kamu.',
  };

  const options = {
    body: data.body,
    icon: '/images/icons/icon-192x192.png',
    vibrate: [100, 50, 100],
  };

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});
